Do not replace the copy of 'gl.h' in this folder.
It is parsed by the QB64 compiler purely for constants and function definitions.
It is parsed once on each QB64 start-up.
Other copies of 'gl.h' will not be parsed properly.
For all current implementations of QB64 (32 or 64 bit, Linux/Windows/MacOSX) this copy will suffice.

If a function definition or constant has been missed please feel free to update this file.
