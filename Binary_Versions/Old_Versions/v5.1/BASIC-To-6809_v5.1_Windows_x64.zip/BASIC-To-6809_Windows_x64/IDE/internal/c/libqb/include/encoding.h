//-----------------------------------------------------------------------------------------------------
//  QB64-PE Encoding Library
//  Powered by MODP_B64 (https://github.com/client9/stringencoders)
//-----------------------------------------------------------------------------------------------------

#pragma once

struct qbs;

qbs *func__base64encode(qbs *src);
qbs *func__base64decode(qbs *src);
