#ifndef RESOURCE_H
#define   RESOURCE_H
#ifdef    __cplusplus
extern "C" {
#endif
#ifdef    __cplusplus
}
#endif
#endif    /* RESOURCE_H */
#define CREATEPROCESS_MANIFEST_RESOURCE_ID 1 /*Defined manifest file*/
#define RT_MANIFEST                       24
