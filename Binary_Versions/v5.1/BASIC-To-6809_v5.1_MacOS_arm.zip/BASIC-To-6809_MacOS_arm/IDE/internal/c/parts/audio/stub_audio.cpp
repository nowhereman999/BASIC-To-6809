#include "audio.h"

void snd_mainloop() {}

void snd_init() {}

void snd_un_init() {}
